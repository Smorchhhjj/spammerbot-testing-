import asyncio
import logging
import os
import sys
from discord import Client, NotFound, Forbidden, HTTPException

from parse_data import parse_tokens_from_file, parse_http_proxies_from_file

file_log = logging.FileHandler('./log.txt', encoding="utf-8-sig")
console_out = logging.StreamHandler()
logging.basicConfig(format=u'%(filename)s [LINE:%(lineno)d] #%(levelname)-8s [%(asctime)s]  %(message)s', level=logging.WARNING, handlers=(file_log, console_out))


class MyClient(Client):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.invite_code = kwargs["invite_code"].replace("https://discord.gg/", "").replace("invite/", "")
        self.account_number: int = kwargs["account_number"] + 1
        self.count_accounts: int = kwargs["count_accounts"]

    async def on_ready(self):
        logging.warning(f"[{self.account_number}/{self.count_accounts}] Successfully logged as {self.user}")
        try:
            invite_data = await self.fetch_invite(self.invite_code)
            guild_name = invite_data.guild.name

        except (Exception,):
            logging.error(f"[{self.account_number}/{self.count_accounts}] Произошла ошибка во время получения инвайта.")
            await self.close()
            return

        try:
            invite_link = f"https://discord.gg/{self.invite_code}"
            logging.warning(f"Аккаунта {self.user} нету на сервере {guild_name}. Присоединяюсь по {invite_link} на сервер...")
            guild_data = await self.accept_invite(self.invite_code)
            logging.warning(f"[{self.account_number}/{self.count_accounts}] Аккаунт {self.user} успешно присоединен к серверу {guild_name}")

        except NotFound:
            logging.error(f"[{self.account_number}/{self.count_accounts}] Аккаунт {self.user} был введен неправильный инвайт!")

        except Forbidden:
            logging.error(f"[{self.account_number}/{self.count_accounts}] Аккаунт {self.user} видимо не верифицирован.")

        except HTTPException as e:
            logging.warning(f"[{self.account_number}/{self.count_accounts}] На аккаунте {self.user} капча!")

        except Exception as e:
            logging.error(f"[{self.account_number}/{self.count_accounts}] Ошибка >> {e}")

        await self.close()


def parse_answer_to_bool(answer: str) -> bool:
    answer = answer.strip().lower()
    if answer == "yes" or answer == "y" or answer == "":
        return True
    else:
        return False


async def start():
    os.system("cls||clear")  # Чистим консоль на Windows и Linux

    print("""██╗███╗   ██╗██╗   ██╗██╗████████╗███████╗██████╗ 
██║████╗  ██║██║   ██║██║╚══██╔══╝██╔════╝██╔══██╗
██║██╔██╗ ██║██║   ██║██║   ██║   █████╗  ██████╔╝
██║██║╚██╗██║╚██╗ ██╔╝██║   ██║   ██╔══╝  ██╔══██╗
██║██║ ╚████║ ╚████╔╝ ██║   ██║   ███████╗██║  ██║
╚═╝╚═╝  ╚═══╝  ╚═══╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝

created by @crypto_satana | @scissor_eth\n""")

    kwargs_dict = {}

    count_tokens: int = int(input("Введи сколько аккаунтов использовать >> ").strip())
    use_proxy: bool = parse_answer_to_bool(input("Использовать прокси (Y/n)? >> ").strip().lower())
    tokens_list: list[str] = parse_tokens_from_file("tokens.txt")[:count_tokens]  # Парсим токены из файла
    count_accounts = len(tokens_list)

    if use_proxy:
        proxies_list: list[str] = parse_http_proxies_from_file(path="proxies.txt")  # Парсим прокси к аккаунтам из файла
        if len(proxies_list) < count_accounts:
            logging.error("[ERROR] Количество прокси не совпадает с количеством токенов!")
            sys.exit()

    invite_code = input("Введи ссылку на сервер >> ").strip()

    for account_number, client_token in enumerate(tokens_list):  # Проходимся по списку токенов. number - индекс в списке, client_token - сам токен
        kwargs_dict["account_number"] = account_number + 1

        if use_proxy:
            proxy_url = proxies_list[account_number]  # Берем прокси соответсвующий дискорд аккаунту
            client = MyClient(proxy_url=proxy_url, invite_code=invite_code, account_number=account_number, count_accounts=count_accounts)  # Запуск клиента с прокси
        else:
            client = MyClient(invite_code=invite_code, account_number=account_number, count_accounts=count_accounts)  # Запуск клиента без прокси

        try:
            await client.login(client_token)  # Пытаемся залогиниться по токену
            await client.connect()  # И приконектиться и запустить on_ready

        except (Exception, ):
            logging.warning(f"[НЕВАЛИДНЫЙ ТОКЕН] [{account_number + 1}/{count_accounts}] Токен {client_token} просрочен или не работает прокси.")


loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.run_until_complete(start())
